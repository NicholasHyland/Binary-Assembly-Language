typedef struct node {
	long value;
	struct node *next;
}node;
